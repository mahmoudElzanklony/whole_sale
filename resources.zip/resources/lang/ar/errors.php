<?php

return [
  'image_error'=>'من فضلك ارفع امتداد صحيح يكون png او jpeg او jpg او gif',
  'file_invalid_image_pdf'=>'أمتداد الملف غير صحيح من فضلك لابد ان يكون صوره او ملف pdf',
  'unauthenticated'=>'رقم الهاتف او كلمه المرور غير صحيحه',
    'unauthenticated_serial'=>'رقم الهاتف او رمز الكود غير صحيح',
    'error_upload_image'=>'لابد ان يكون نوع الملف صورة',
    'unauthorized'=>'غير مسموح لك بتنفيذ هذا الامر',
    'payment_before'=>'تم دفع هذا الاعلان من قبل',
    'payment_unauthorized_user'=>'انت لست صاحب هذا الاعلان',
    'not_enough_points'=>'ليس لديك رصيد كافي من النقاط',
];
