<template>
    <section class="profile">
        <navbar-component></navbar-component>
        <div class="inner-profile">
            <ProfileNavComponent></ProfileNavComponent>
            <div class="change_data">
                <div class="container">
                  <p class="alert alert-warning">{{ keywords.there_is_no_offers_yet }}</p>
                </div>
            </div>
        </div>
        <footer-component></footer-component>
    </section>
</template>

<script>
import NavbarComponent from "../../components/NavbarComponent";
import FooterComponent from "../../components/FooterComponent";
import ProfileNavComponent from "../../components/ProfileNavComponent";
export default {
    name: "offers",
    props:['keywords'],
    components: {ProfileNavComponent, FooterComponent, NavbarComponent}
}
</script>
