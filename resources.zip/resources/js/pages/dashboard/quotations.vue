<template>
    <div class="dashboard">
        <side-navbar-component></side-navbar-component>
        <div class="content users table-data-page">
            <div class="container mb-4">
                <p class="d-flex mb-3 align-items-center justify-content-between main-title-toggle">
                    <span>{{ main_title }}</span>
                    <button v-if="false" class="btn black-btn btn-outline-primary"
                            data-toggle="modal" data-target="#update_box" @click="update_item(null)">
                        {{ switchWord('add_new_item') }}
                    </button>
                </p>

                <div class="m-auto mb-3 filters last-quotations-filter">
                    <form>
                        <p>
                            <input type="radio" name="is_completed" :value="switchWord('sent_to_admin')">
                            <span>{{ switchWord('sent_to_admin') }}</span>
                        </p>
                        <p>
                            <input type="radio" name="is_completed" :value="keywords.reply_from_admin">
                            <span>{{ keywords.reply_from_admin }}</span>
                        </p>
                        <p>
                            <input type="radio" name="is_completed" :value="keywords.order_confirmed">
                            <span>{{ keywords.order_confirmed }}</span>
                        </p>
                        <p>
                            <input type="radio" name="is_completed" :value="switchWord('order_confirmed')">
                            <span>{{ switchWord('order_confirmed') }}</span>
                        </p>
                    </form>
                </div>

                <div class="overflow-auto data">
                    <table class="myTableServer table text-center table-bordered table-striped table-hover">
                        <thead>
                        <tr>
                            <td></td>
                            <td v-for="(i,index) in handling_data['table_head_keys']"
                                :name="index"
                                :key="index">
                                <p :name="index">{{ i }}</p>
                            </td>
                        </tr>
                        </thead>
                        <tbody>
<!--

                        <tr v-for="(i,index) in vuex_data"
                             :style="i['is_completed'] == 3 ? 'background-image:linear-gradient(0deg, #82aed4, transparent)':''"
                            :key="index" :class="'row_'+index">
                            <td>
                                <input type="checkbox" @click="detect_row_to_export">
                            </td>
                            <td>{{ i['user']['username'] }}</td>

                            <td>
                                <button class="btn btn-outline-primary"
                                        data-toggle="modal"
                                        @click="get_data_of_quotation(i['id']); update_item(i)"
                                        data-target="#my_quotations"
                                >
                                    {{ switchWord('see_details') }}
                                </button>
                            </td>
                            <td>
                                <p v-if="i['is_completed'] == 0">{{ keywords.wait_to_send_file_quotation }}</p>
                                <p v-else-if="i['is_completed'] == 1">
                                    {{ keywords.file_send_and_wait_from_client_to_confirm_request }}
                                </p>
                                <p v-else-if="i['is_completed'] == 2">
                                    <span>{{ keywords.client_confirm_request }}</span>
                                    <button class="confirm"
                                            @click="finish_order(i)">{{ keywords.click_here_to_finish_request }}</button>
                                </p>
                                <p v-else-if="i['is_completed'] == 3">
                                    <span>{{ keywords.complete_request_successfully }}</span>
                                </p>
                            </td>
                            <td>{{ new Date(i['created_at']).toLocaleString() }}</td>
                            <td>
                                <button v-if="i['is_completed'] >= 1" class="btn btn-outline-primary"
                                        data-toggle="modal"
                                        @click="get_data_admin_of_quotation(i['id'])"
                                        data-target="#admin_quotation_data">
                                    {{ switchWord('see_details') }}
                                </button>
                            </td>
                            <td class="actions">
                                <span class="accept" v-if="false">
                                    <i
                                       class="ri-check-line">
                                    </i>
                                </span>
                                <span
                                    data-toggle="modal"
                                    @click="item = i"
                                    data-target="#upload_excel"
                                    >
                                    <i class="ri-upload-2-line"></i>
                                </span>
                                <span class="delete"  @click="delete_item('quotation_orders'
                                       ,i['id'],'.row_'+index)"><i class="ri-close-line"></i></span>
                            </td>
                        </tr>
-->

                        </tbody>
                    </table>
                </div>
            </div>
        </div>



         <div  class="modal fade" id="my_quotations"
              v-if="get_my_quotation != null"
              tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="my_quotations_box">
                            {{ switchWord('see_details') }}
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="loading-img">
                            <img src="/images/loading.gif">
                        </div>
                        <div class="overflow-auto">
                            <table class="myTable box-model-table table text-center table-bordered table-striped table-hover">
                                <thead>
                                <tr>
                                    <td></td>
                                    <td>{{ keywords.brand }}</td>
                                    <td>{{ keywords.part_no }}</td>
                                    <td>{{ keywords.quantity }}</td>
                                    <td>{{ keywords.actions }}</td>
                                </tr>
                                </thead>
                                <tbody>
                                <tr v-for="(i,index) in get_my_quotation"
                                    :key="index" :class="'row_child_'+index"
                                    v-if="i['last_draft'].length == 0 || i['last_draft'][0]['deleted_at'] == null">
                                    <td>
                                        <input type="checkbox" @click="detect_row_to_export">
                                    </td>
                                    <td>{{ i['last_draft'].length == 0 ? i['brand']['name']:
                                        i['last_draft'][0]['brand']['name'] }}
                                    </td>
                                    <td>{{ i['last_draft'].length == 0 ? i['part_number']:
                                        i['last_draft'][0]['part_number'] }}</td>
                                    <td>{{ i['last_draft'].length == 0 ? i['quantity']:i['last_draft'][0]['quantity'] }}</td>
                                    <td class="actions" >
                                         <span data-toggle="modal" v-if="i['last_draft'].length > 0"
                                               @click="item = i"
                                               :title="switchWord('see_edits')"
                                               data-target="#old_update">
                                             <i class="ri-file-line"></i>
                                         </span>
                                        <p v-else>{{ switchWord('no_edits_history') }}</p>
                                    </td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            {{ switchWord('close') }}
                        </button>
                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade" id="admin_quotation_data"
             tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="admin_quotation_data_box">
                            {{ switchWord('see_details') }}
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="loading-img">
                            <img src="/images/loading.gif">
                        </div>
                        <div class="overflow-auto">
                            <table class="myTable box-model-table table text-center table-bordered table-striped table-hover">
                                <thead>
                                <tr>
                                    <td></td>
                                    <td>{{ keywords.seq }}</td>
                                    <td>{{ keywords.part_no }}</td>
                                    <td>{{ keywords.brand }}</td>
                                    <td>{{ keywords.offered_stock }}</td>
                                    <td>{{ keywords.min_quantity_per_transaction }}</td>
                                    <td>{{ keywords.max_quantity_per_transaction }}</td>
                                    <td>{{ keywords.unit_price }}</td>
                                    <td>{{ keywords.estimated_required_days_for_delivery }}</td>
                                    <td>{{ keywords.actions }}</td>
                                </tr>
                                </thead>
                                <tbody>
                                <tr v-for="(i,index) in admin_quotation"
                                    :key="index" :class="'row_child_'+index">
                                    <td>
                                        <input type="checkbox" @click="detect_row_to_export">
                                    </td>
                                    <td>{{ index + 1 }}</td>
                                    <td>{{ i['part_number'] }}</td>
                                    <td>{{ i['brand']['name'] }}</td>
                                    <td>{{ i['offered_stock'] }}</td>
                                    <td>{{ i['min_quantity_per_transaction'] }}</td>
                                    <td>{{ i['max_quantity_per_transaction'] }}</td>
                                    <td>{{ i['prices'][0]['price'] }}</td>
                                    <td>{{ 3 }}</td>
                                    <td v-if="i['prices'].length >= 2">
                                        <button class="btn btn-outline-primary"
                                                @click="current_admin_quotation = i"
                                                data-toggle="modal"
                                                data-target="#see_prices"
                                        >{{ keywords.see_prices }}</button>
                                    </td>

                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            {{ switchWord('close') }}
                        </button>
                    </div>
                </div>
            </div>
        </div>



        <div class="modal fade" id="see_prices"
             v-if="current_admin_quotation != null"
             tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="see_prices_box">
                            {{ switchWord('see_details') }}
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <div class="overflow-auto">
                            <table class="box-model-table table text-center table-bordered table-striped table-hover">
                                <thead>
                                <tr>
                                    <td>{{ keywords.seq }}</td>
                                    <td>{{ keywords.min_quantity }}</td>
                                    <td>{{ keywords.price }}</td>
                                </tr>
                                </thead>
                                <tbody>
                                <tr v-for="(i,index) in current_admin_quotation['prices']"
                                    :key="index" :class="'row_child_'+index">
                                    <td>{{ index + 1 }}</td>
                                    <td>{{ i['min_quantity'] }}</td>
                                    <td>{{ i['price'] }}</td>
                                </tr>
                                </tbody>
                            </table>
                        </div>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            {{ switchWord('close') }}
                        </button>
                    </div>
                </div>
            </div>
        </div>


        <div class="modal fade" id="upload_excel"
             tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
            <div class="modal-dialog" role="document">
                <div class="modal-content">
                    <div class="modal-header">
                        <h5 class="modal-title" id="upload_excel_box">
                            {{ switchWord('upload_quotation_file') }}
                        </h5>
                        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                            <span aria-hidden="true">&times;</span>
                        </button>
                    </div>
                    <div class="modal-body">
                        <form  method="post" @submit.prevent="send_excel">
                            <input v-if="item != null" type="hidden" name="quotation_order_id" :value="item.id">
                            <div class="form-group">
                                <div class="drag-drop-files mb-3" data-aos="fade-up" data-aos-delay="2000">
                                    <input type="file" name="excel_file"
                                          >
                                    <p class="alert alert-danger"></p>
                                    <button type="button" class="btn btn-primary">
                                        <span>{{ keywords.excel_file }}</span>
                                        <span><i class="ri-add-line"></i></span>
                                    </button>
                                </div>
                            </div>
                            <div class="form-group">
                                <input class="btn btn-primary"
                                       type="submit" name="send" :value="switchWord('save')">
                            </div>
                        </form>
                    </div>
                    <div class="modal-footer">
                        <button type="button" class="btn btn-secondary" data-dismiss="modal">
                            {{ switchWord('close') }}
                        </button>
                    </div>
                </div>
            </div>
        </div>




        <div class="modal fade" id="old_update"
                     v-if="item != null"
                     tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                    <div class="modal-dialog" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title" id="update_quotations_box" v-if="item != null">
                                    {{ switchWord('see_details') }}
                                </h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <div class="overflow-auto">
                                    <table class="table text-center table-bordered table-striped table-hover">
                                        <thead>
                                        <tr>
                                            <td v-for="i in handling_data['table_head_keys_model']" :key="i"
                                                v-if="i != 'actions'">
                                                {{ i }}
                                            </td>
                                        </tr>
                                        </thead>
                                        <tbody>
                                        <tr v-for="(i,index) in item['last_draft']"
                                            :key="index" :class="'row_child_'+index">
                                            <td>{{ i['brand']['name'] }}</td>
                                            <td>{{ i['part_number'] }}</td>
                                            <td>{{ i['quantity'] }}</td>
                                            <td>{{ new Date(i['created_at']).toLocaleString() }}</td>
                                            <td>{{ i['deleted_at'] != null ?
                                                switchWord('delete_item'):switchWord('update_new_item') }}</td>
                                        </tr>
                                        <tr v-if="item.hasOwnProperty('last_draft') && item['last_draft'].length > 0">
                                            <td>{{ item['last_draft'][0]['brand']['name'] }}</td>
                                            <td>{{ item['last_draft'][0]['part_number'] }}</td>
                                            <td>{{ item['quantity'] }}</td>
                                            <td>{{ new Date(item['created_at']).toLocaleString() }}</td>
                                            <td>{{ switchWord('basic_value') }}</td>
                                        </tr>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button type="button" class="btn btn-secondary" data-dismiss="modal">
                                    {{ switchWord('close') }}
                                </button>
                            </div>
                        </div>
                    </div>
                </div>

    </div>
</template>

<script>
import SideNavbarComponent from "../../components/dashboard/SideNavbarComponent";
import tableData from "../../mixin/tableData";
import tableDataServer from "../../mixin/tableDataServer";
import SwitchLangWord from "../../mixin/SwitchLangWord";
import delete_item from "../../mixin/delete_item";
import update_item from "../../mixin/update_item";
import detect_row_for_export from "../../mixin/detect_row_for_export";
import {mapState,mapActions , mapGetters , mapMutations} from "vuex";
import TableData from "../../mixin/tableData";
export default {
    name: "quotations",
    mixins:[tableData,SwitchLangWord,update_item,delete_item,detect_row_for_export,tableDataServer],
    props:['main_title','handling_data','keywords'],
    data:function(){
        return {
            modal_data:[],
            quotations_info:[],
            current_admin_quotation:null,
            table_url:'/paginate-data',
            table_requested_table:'quotation_orders',
            table_columns:null,
            page_data:null,
        }
    },
    computed:{
        ...mapGetters({
            'get_my_quotation':'quotations_dash/get_data_quotations',
            'vuex_data':'quotations_dash/get_data',
            'admin_quotation':'quotations_dash/get_data_quotations_admin',
            'all_brands':'brands/get_brands',

        })
    },
    mounted() {
        let all_thead_tds = document.querySelectorAll
        ('.myTableServer thead tr td:nth-of-type(2) p,.myTableServer thead tr td:nth-of-type(3) p,.myTableServer thead tr td:nth-of-type(4) p,.myTableServer thead tr td:nth-of-type(6) p');
        for( let input of all_thead_tds){
            console.log(input);
            input.innerHTML = '<input class="form-control" name="' + input.parentElement.getAttribute('name') + '" placeholder="' + input.textContent.trim() + '">';
        }
    },
    created() {
        this.inlize_data(this.handling_data['data']);
        var component = this;
        this.table_columns = [
            { "data": "id",
                "render":function(data,type,row){
                    return '<input type="checkbox" @click="detect_row_to_export">';
                }
            },
            { "data": "id"},
            { "data": "id",
                "render":function(data,type,row){
                    return row['user']['username'];
                }
            },
            { "data": "id",
                "render":function(data,type,row){
                    return row['user']['phone'];
                }
            },
            {"data":"id",
                "render":function (data,type,row){
                    return '<button class="client_request btn btn-outline-primary" el_id="'+row['id']+'">'+component.switchWord('see_details')+'</button>'
                }
            },
            { "data": "is_completed",
                "render":function(data,type,row){
                    return  row['is_completed'] == 0 ? component.switchWord('sent_to_admin')
                        :row['is_completed'] == 1 ? component.keywords.reply_from_admin
                            :row['is_completed'] == 2 ? '<button el_id="'+row['id']+'" class="confirm btn btn-outline-primary">'+component.keywords.click_here_to_finish_request+'</button>' : component.switchWord('order_confirmed');
                }
            },
            { "data": "id", // get my quotation
                "render":function(data,type,row){
                    return new Date(row['created_at']).toLocaleString();
                }
            },
            { "data": "is_completed",
                "render":function(data,type,row){

                    if(row['is_completed'] >= 1){
                        return '<button class="admin_response btn btn-outline-primary" el_id="'+row['id']+'" >'+component.switchWord('see_details')+'</button>'
                    }else{
                        return '';
                    }
                }
            },
            { "data": "id",
                "render":function (data,type,row,option){
                return '<span><i class="ri-upload-2-line" el_id="'+row['id']+'"></i> </span><span class="delete" el_id="'+row['id']+'"><i class="ri-close-line"></i></span>';
                }
            },
        ];

        // add events
        // export file
        $('.content').on('click','.data table tbody tr td:first-of-type',async function (){
            component.detect_row_to_export();
        });
        // show details
        $('.content').on('click','.data table tbody tr td button.client_request',async function (){
            var item = component.get_obj_wanted($(this).attr('el_id'));
            await component.get_data_of_quotation($(this).attr('el_id'));
            await component.update_item(item);
            $('#my_quotations').modal('show');
        });
        // finish order
        $('.content').on('click','.data table tbody tr td button.confirm',async function (){
            var item = component.get_obj_wanted($(this).attr('el_id'));
            await component.finish_order(item);
        });
        // get admin file data reply
        $('.content').on('click','.data table tbody tr td button.admin_response',async function (){
            console.log($(this));
            await component.get_data_admin_of_quotation($(this).attr('el_id'));
            $('#admin_quotation_data').modal('show');
        });
        // upload excel file
        $('.content').on('click','.data table tbody tr td:last-of-type span:first-of-type i',async function (){
            var item = component.get_obj_wanted($(this).attr('el_id'));
            await component.update_item(item);
            $('#upload_excel').modal('show');
        });
        // delete
        $('.content').on('click','.data table tbody tr td:last-of-type span:last-of-type',async function (){
            var item = component.get_obj_wanted($(this).attr('el_id'));
            await component.delete_item('quotation_orders',$(this).attr('el_id'),$(this).parent().parent());
        });
    },
    methods:{

        ...mapActions({
            'get_info_about_quotation':'quotations_dash/get_info_about_quotation',
            'get_info_about_quotation_admin':'quotations_dash/get_info_about_quotation_reply_admin',
            // get brands
            'get_all_brands':'brands/get_brands',
            'update_quotation_at_draft':'quotations_dash/save_quotation_at_draft',
            'send_excel':'quotations_dash/upload_file',
            'finish_order':'quotations_dash/finish_order',

        }),
        get_data_of_quotation:function(id){
            this.get_info_about_quotation(id);
        },
        get_data_admin_of_quotation:function(id){
            this.get_info_about_quotation_admin(id);
        },
        update_sub_quotation:function (item){
            this.sub_quotation = item;
        },
        ...mapMutations({
            'inlize_data':'quotations_dash/inilalize_data',
        }),

    },
    components: {TableData, SideNavbarComponent}
}
</script>

<style lang="scss" scoped>
@import "resources/sass/variables";
.alert-danger{
    display: none;
}

#update_quotations .modal-dialog{
    width: 70%;
    max-width: 900px;
}
.loading-img{
    top: 0;
    right: 0;
    left: 0;
    bottom: 0;
    background-color: white;
    text-align: center;
    margin: auto;
    display: none;
    height: 380px;
}
table{
    tr{
        td{
            p{
                text-align: center;
                button{
                    border: none;
                    outline: none;
                    background-color: transparent;
                    color:$main_color;
                }
            }
        }
    }
}

#my_quotations .modal-dialog,
#old_update .modal-dialog,
#see_prices .modal-dialog,
#admin_quotation_data .modal-dialog{
    max-width: 1100px;
}
</style>
