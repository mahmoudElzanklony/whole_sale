import validation from "../../../formValidation/validation";

export default {
    namespaced:true,
    actions:{

    }
}
