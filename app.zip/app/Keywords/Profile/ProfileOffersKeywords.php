<?php


namespace App\Keywords\Profile;


class ProfileOffersKeywords
{
    public static function get_keywords(){
        return [
            'there_is_no_offers_yet'=>trans('keywords.no_offers')
        ];
    }

}
