<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;

class items_infos_prices extends Model
{
    use HasFactory;

    protected $fillable = ['item_id','min_quantity','price'];
}
