<?php

namespace App\Http\Controllers\classes;

use App\Http\Controllers\Controller;
use App\Http\Requests\brandsFormRequest;
use App\Http\Requests\categoriesFormRequest;
use App\Http\Requests\currenciesFormRequest;
use App\Http\Requests\mapFormRequest;
use App\Http\Requests\packagesFormRequest;
use App\Http\Requests\questionsFormRequest;
use App\Http\Requests\subCategoriesFormRequest;
use App\Http\Requests\supportFormRequest;
use App\Http\Requests\uploadfilesFormRequest;
use App\Http\Requests\usersFormRequest;
use App\Http\traits\messages;
use App\Models\advertising_points_price;
use App\Models\answers;
use App\Models\areas;
use App\Models\brands;
use App\Models\categories;
use App\Models\categories_questions;
use App\Models\cities;
use App\Models\countries;
use App\Models\currencies;
use App\Models\governments;
use App\Models\listing_photos;
use App\Models\listings_info;
use App\Models\map_images;
use App\Models\packages;
use App\Models\packages_prices_places;
use App\Models\questions;
use App\Models\support;
use App\Models\User;
use App\Services\listings\average_price_at_area;
use App\Services\listings\get_pointsprice_of_place;
use App\Services\mail\send_email;
use App\Services\map\get_location_where;
use App\Services\notifications\create_notification;
use App\Services\statistics\filter_statistics_admin;
use Illuminate\Http\Request;
use App\Http\traits\upload_image;

class DashboardServiceClass extends Controller
{
    //
    use upload_image;

    public function save_brand(brandsFormRequest $request){
        $validated = $request->validated();
        if(request()->hasFile('image')){
            $image = $this->upload(request('image'),'brands');
            $validated['image'] = $image;
        }else if(!(request()->has('id'))){
            $validated['image'] = 'default.png';
        }
        $item = brands::query()->updateOrCreate([
            'id'=>request()->has('id') ? request('id'):null
        ],$validated);

        return messages::success_output(trans('messages.saved_successfully'),$item,request()->has('id') ? 'update':'insert');
    }

    // save question

    public function save_user(usersFormRequest $request){
        $validated = $request->validated();
        // check if image has been uploaded
        if(request()->hasFile('image')){
            $image = $this->upload(request('image'),'users');
            $validated['image'] = $image;
        }else if(!(request()->has('id'))){
            $validated['image'] = 'default.png';
        }
        // check if password is updated
        if(request()->has('password')){
            $validated['password'] = bcrypt(request('password'));
        }
        $item = User::query()->updateOrCreate([
            'id'=>request()->has('id') ? request('id'):null
        ],$validated);
        $item = User::query()->find(request('id'));
        return messages::success_output(trans('messages.saved_successfully'),$item,request()->has('id') ? 'update':'insert');

    }

    public function save_support(supportFormRequest $request){
        $data = $request->validated();
        $item = support::query()->updateOrCreate([
            'id'=>request()->has('id') ? request('id'):null
        ],$data);
        // send email
        $title = 'هذه رساله من اداره موقع ايواء';
        send_email::send($title,request('reply'),'','',request('email'));
        return messages::success_output(trans('messages.saved_successfully'),$item,request()->has('id') ? 'update':'insert');

    }


    public function save_files(){
        if(request()->hasFile('quotation_file')){
            $file = request()->file('quotation_file');
            $extension = strtolower($file->getClientOriginalExtension());

            if(in_array($extension, ['csv', 'xls', 'xlsx'])) {
                $name = 'template.' . $file->getClientOriginalExtension();
                $file->move(public_path('excels/'), $name);
            }
        }
        if(request()->hasFile('product_file')){
            $product_file = request()->file('product_file');
            $extension = strtolower($product_file->getClientOriginalExtension());
            if(in_array($extension, ['csv', 'xls', 'xlsx'])) {
                $product_name = 'product_template.' . $product_file->getClientOriginalExtension();
                $product_file->move(public_path('excels/'), $product_name);
            }
        }
        return messages::success_output(trans('messages.saved_successfully'));
    }

    public function save_pointad(){
        switch(request('type')){
            case 'countries':{$place_id = request('country_id');} break;
            case 'governments':{$place_id = request('government_id');} break;
            case 'cities':{$place_id = request('city_id');} break;
            case 'areas':{$place_id = request('area_id');} break;
        }
        $data = [
            'type'=>request('type'),
            'place_id'=>$place_id,
            'no_points'=>request('no_points'),
        ];
        $d = advertising_points_price::query()->updateOrCreate([
            'id'=>request()->has('id') ? request('id'):null
        ],$data);


        if($d->type == 'countries'){
            $d['place'] = countries::query()->find($d['place_id']);
        }else if ($d->type == 'governments'){
            $d['place'] = governments::query()->find($d['place_id']);
        }else if ($d->type == 'cities'){
            $d['place'] = cities::query()->find($d['place_id']);
        }else if ($d->type == 'areas'){
            $d['place'] = areas::query()->find($d['place_id']);
        }


        return messages::success_output(trans('messages.saved_successfully'),$d,request()->has('id') ? 'update':'insert');

    }

    public function save_settings(usersFormRequest $request){
        $validated = $request->validated();
        if(request()->has('password') && request()->filled('password')){
            $validated['password'] = bcrypt(request('password'));
        }
        $user = User::query()->where('id','=',auth()->id())->update($validated);
        return messages::success_output(trans('messages.saved_successfully'));
    }

    public function accept_listing(){
        $id = request('id');
        $listing = listings_info::query()->findOrFail($id);
        $listing->type = 'live';
        $listing->save();
    }

}
